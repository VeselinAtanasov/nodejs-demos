const fileUploadController = require('./file-controller');
const homeController = require('./home-controller');

module.exports = [homeController];
