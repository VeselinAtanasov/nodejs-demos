const fs = require('fs');

class FileAPI {
  constructor (req, res) {
    this.req = req;
    this.res = res;
  }
  loadHtmlFile (filePath) {
    console.log(this.res);
    let that = this;
    return new Promise(function (resolve, reject) {
      fs.readFile(`./views/${filePath}`, 'utf8', (err, data) => {
        if (err) {
          reject(err);
          return;
        }
        console.log('=====================');
        // console.log(this.res);
        console.log('=====================');
        this.res.writeHead(200, {
          'content-type': 'text/html'
        });
        this.res.write(data);
        this.res.end();
        resolve();
      });
    });
  }
  move (filePath, fileName) {
    return new Promise(function (resolve, reject) {
      fs.rename(filePath, './files/' + fileName, (err) => {
        if (err) {
          reject(err);
          return;
        }
        this.res.writeHead(200, {
          'content-type': 'text/plain'
        });
        this.res.write('File Uploaded');
        this.res.end();
        resolve();
      });
    });
  }
}

module.exports = FileAPI;

/*
module.exports = {
  loadHtmlFile: function (req, res, filePath) {
    return new Promise(function (resolve, reject) {
      fs.readFile(`./views/${filePath}`, 'utf8', (err, data) => {
        if (err) {
          reject(err);
          return;
        }
        res.writeHead(200, {
          'content-type': 'text/html'
        });
        res.write(data);
        res.end();
        resolve();
      });
    });
  },
  move: function (req, res, filePath, fileName) {
    return new Promise(function (resolve, reject) {
      fs.rename(filePath, './files/' + fileName, (err) => {
        if (err) {
          reject(err);
          return;
        }
        res.writeHead(200, {
          'content-type': 'text/plain'
        });
        res.write('File Uploaded');
        res.end();
        resolve();
      });
    });
  }
};
*/
